# VivaTech Viral/Polemic Pattern Bank

Generated from the normalized VivaTech company and speaker scrape.

## Sharpest Claims

|rank|claim|evidence|caveat|score|
|---:|---|---|---|---:|
|1|Partners are 21.2x louder per company than startups.|Partners are 13.8% of exhibitors but 77.2% of matched speaker slots; startup exhibitors are 86.2% of the floor but 22.8% of matched speaker slots.|Only speakers whose organizations conservatively match exhibitors are included; unmatched speakers may change some shares but not the exhibitor-side imbalance.|5|
|2|93.9% of exhibitors appear voiceless in the speaker program.|Only 191 of 3153 exhibitors have at least one matched speaker; for startups the no-matched-speaker rate is 97.4%.|This is based on public listing data and conservative organization matching, not internal stage selection data.|5|
|3|The US has fewer booths than India, but roughly 27x the matched-speaker density.|US: 73 exhibitors and 68 matched speakers (93.2 per 100 companies). India: 88 exhibitors and 3 matched speakers (3.4 per 100).|Country values come from exhibitor records after matching; country normalization and unmatched speaker organizations can move this metric.|5|
|4|Retail has 337 exhibitors but only 6 speakers: a booth-heavy topic with almost no mic.|Retail & E-commerce is 10.7% of exhibitor tags but 0.5% of speaker tags, a -10.2 percentage point speaker under-index.|Tag fields are multi-select listing tags, so counts represent tagged records rather than exclusive categories.|4|
|5|AI is so saturated that it has stopped being the interesting label.|1513 of 3153 exhibitors (48.0%) and 528 of 1133 speakers (46.6%) carry the AI/Robotics tag.|This is tag-level saturation, not a measure of product depth, revenue, or actual AI capability.|4|
|6|Korea has 153 exhibitor records after normalizing the split label, but only 2 matched speakers.|`South Korea` has 96 exhibitors and `korearepublicof` has 57. Combined density is 1.3 matched speakers per 100 companies, versus 93.2 for the US.|The raw country split must be normalized before any official country ranking; unmatched Korean speaker organizations may be missing from the conservative match.|4|
|7|Among explicit funding labels, Series C startups have about 8x the mic density of bootstrapped companies.|Series C: 16.7 matched speakers per 100 companies. Bootstrapped: 2.1 per 100. Pre-seed: 2.3 per 100.|Series C has only 24 companies, and partner records often have unspecified fundraising; use this as a directional signal, not a causal claim.|4|
|8|The speaker program is a boss layer: 58.4% are CEOs/founders/C-suite.|CEO/president/GM, founder/co-founder, and other C-suite buckets total 662 of 1133 speakers. Government/public-sector speakers are only 2.6% of speakers but are top-billed at 23.3% inside their bucket, 5.6x the overall top-speaker rate.|Role buckets are keyword-derived from public job titles and should be reviewed manually before publication.|4|
|9|The public exhibitor list is a taxonomy machine, not a discovery engine.|3153 exhibitor short descriptions are empty (100.0%), and 1349 fundraising fields are missing (42.8%).|Detail pages may contain richer text; this claim is scoped to the listing payload used for bulk discovery.|3|
|10|A few organizations can bend the agenda more than thousands of booths can.|The top 10 speaker organizations account for 74 speaker records (6.5% of all speakers), led by L'Oreal and PwC.|The top-organization table uses displayed speaker organization names; some subsidiaries and country suffixes may split or merge imperfectly.|3|

## How To Use These Claims Without Overclaiming

- Say "matched speaker" when making exhibitor-stage overlap claims.
- Say "speaker density" rather than "influence" unless you have independent influence evidence.
- Treat country results as directional until raw country labels are normalized.
- Avoid fuzzy company matching in viral claims unless a manual review sample is added.
- The strongest defensible polemic is structural: VivaTech's floor is startup-heavy, but its matched microphone layer is partner-heavy.

## Generated Visuals

- `01_partner_agenda_capture.svg` - partner_agenda_capture
- `01_partner_agenda_capture.svg` - voiceless_floor
- `02_country_mic_leverage.svg` - country_agenda_leverage
- `02_country_mic_leverage.svg` - korea_silent_supply
- `03_tag_silence.svg` - retail_silence
- `05_funding_mic_odds.svg` - funding_mic_odds
- `06_boss_stage.svg` - boss_stage
- `07_ai_cotags.svg` - ai_saturation
- `07_ai_cotags.svg` - directory_opacity
- `04_speaker_org_power.svg` - speaker_org_concentration
